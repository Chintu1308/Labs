#include <stdio.h>
#include <unistd.h>
int main()
{
    int count;
    count = write(1, "hello\n", 6);
    printf("Total bytes written: %d\n", count);
    return 0;
}